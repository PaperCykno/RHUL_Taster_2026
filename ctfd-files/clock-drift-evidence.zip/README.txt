RHUL Cyber Security Society - Incident 47
================================================

An event archive was accessed during taster-session setup.

Five systems were collected before their clocks could be corrected.

Facilities has confirmed that the FIRE_TEST happened at exactly:

    21:30:00

All times are on the same date and should be treated as local
wall-clock times.

The device clocks may be fast or slow.

Your job:

1. Determine the badge number involved.
2. Determine the account that downloaded /event/archive.zip.
3. Determine the TRUE time of that download.

Flag format:

    rhul{BADGE_USERNAME_HHMMSS}

Example only:

    rhul{1234_example-user_211530}

The example above is NOT the answer.
