# Changelog

## 1.4

- Improved event configuration
- Updated logging
- Added validation documentation
- Updated compatibility support

## 1.3

- Initial freshers tooling