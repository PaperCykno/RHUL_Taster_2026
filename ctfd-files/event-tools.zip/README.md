# RHUL CSS Event Tools

Internal utilities used during society events.

The project contains configuration,
display and compatibility helpers.

Current release: 1.4