# Event Setup

1. Start the scoreboard.
2. Check projector output.
3. Verify challenge links.
4. Confirm volunteer access.
5. Test spare equipment.