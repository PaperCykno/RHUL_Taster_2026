def refresh_scoreboard():
  return True